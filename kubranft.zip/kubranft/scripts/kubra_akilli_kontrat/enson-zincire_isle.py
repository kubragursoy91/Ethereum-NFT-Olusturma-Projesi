#!/usr/bin/python3
from brownie import SimpleCollectible, kgNFT, accounts, network, config
from metadata import metadata_sablon
from scripts.yardimci_script import get_kubra_resim, OPENSEA_FORMAT


kubra_resim_metadata_dic = {
    "KG_1": "https://ipfs.io/ipfs/QmbiyToZBtniy7ew2kQhtLvC5P6mGtvuu9YtwrrbHtZonV?filename=0-KG_1.json", 
    "KG_2": "https://ipfs.io/ipfs/QmbiyToZBtniy7ew2kQhtLvC5P6mGtvuu9YtwrrbHtZonV?filename=0-KG_2.json",
    "KG_3": "https://ipfs.io/ipfs/QmbiyToZBtniy7ew2kQhtLvC5P6mGtvuu9YtwrrbHtZonV?filename=0-KG_3.json",
}

def main():
    print("Working on " + network.show_active())
    akilli_kontrat = kgNFT[len(kgNFT) - 1]

    number_of_advanced_collectibles = akilli_kontrat.tokenCounter()
    print(
        "The number of tokens you've deployed is: "
        + str(number_of_advanced_collectibles)
    )
    for token_id in range(number_of_advanced_collectibles):
        kubra_resim = get_kubra_resim(akilli_kontrat.tokenIdToKubraResim(token_id))
        if not akilli_kontrat.tokenURI(token_id).startswith("https://"):
            print("Setting tokenURI of {}".format(token_id))
            set_tokenURI(token_id, akilli_kontrat,kubra_resim_metadata_dic[kubra_resim])
        else:
            print("Skipping {}, we already set that tokenURI!".format(token_id))


def set_tokenURI(token_id, nft_contract, tokenURI):
    dev = accounts.add(config["wallets"]["from_key"])
  

    nft_contract.setTokenURI(token_id, tokenURI, {"from": dev})

    print(
        "Awesome! You can view your NFT at {}".format(
            OPENSEA_FORMAT.format(nft_contract.address, token_id)
        )
    )
    print('Please give up to 20 minutes, and hit the "refresh metadata" button')
