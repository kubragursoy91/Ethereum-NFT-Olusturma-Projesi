from brownie import kgNFT, accounts, config
from scripts.yardimci_script import get_kubra_resim,fund_with_link
import time



def main():

    dev = accounts.add(config["wallets"]["from_key"])
    akilli_kontrat = kgNFT[len(kgNFT) - 1]
    
    transaction = akilli_kontrat.createCollectible("None", {"from": dev})

    print("Waiting on second transaction...")
    transaction.wait(1)
    time.sleep(5)

    requestId = transaction.events['requestedCollectible']['requestId']
    token_id = akilli_kontrat.requestIdToTokenId(requestId)
    kubra_resim  = get_kubra_resim(akilli_kontrat.tokenIdToKubraResim(token_id))

    print('Logo of tokenId {} is {}'.format(token_id, kubra_resim))
